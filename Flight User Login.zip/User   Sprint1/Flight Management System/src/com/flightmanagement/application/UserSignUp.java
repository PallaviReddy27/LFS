package com.flightmanagement.application;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import com.flightmanagement.dto.UserDetails;
import com.flightmanagement.service.FlightService;
import com.flightmanagement.service.FlightServiceImpl;
public class UserSignUp {
	public static void main(String[] args) {
		 while(true)
		 {
			System.out.println("1. New user");
			System.out.println("2. Exit");
			System.out.println("Enter your choice");
			@SuppressWarnings("resource")
			Scanner s=new Scanner(System.in);
			BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
			FlightService Service=new FlightServiceImpl();
			int choice=s.nextInt();
			switch(choice)
			{
			case 1:
			{
				 try
				 {
				 System.out.println("Enter your User-Id");
				 int userid=Integer.parseInt(sc.readLine());
				 System.out.println("Enter your User-Type");
				 String usertype=sc.readLine();
				 System.out.println("Enter your user-name");
				 String username=sc.readLine();
				 System.out.println("Enter your password");
				 String password=sc.readLine();
				 System.out.println("Enter your phone number");
				 long phoneno=Long.parseLong(sc.readLine());
				 System.out.println("Enter your email");
				 String useremail=sc.readLine();
				 System.out.println("Enter user state");
				 String userstate=sc.readLine();
				 UserDetails ud=new UserDetails(userid,usertype,username,password,phoneno,useremail,userstate);
				 Service.Signup(ud);
				 }
				 catch(IOException e)
				 {
					 e.printStackTrace();
				 }
					break;
			}
			case 2:
				System.exit(0);
			}
		 }
	}
}
