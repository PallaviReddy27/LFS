package com.flightmanagement.application;
import java.util.Scanner;
import com.flightmanagement.service.FlightService;
import com.flightmanagement.service.FlightServiceImpl;
import com.flightmanagement.utils.LoginInvalidException;
public class UserLogin 
{
	@SuppressWarnings("resource")
	public static void main(String[] args) 
	{
        
		FlightService service = new FlightServiceImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("User Id : ");
		String uid = sc.nextLine();
		System.out.println("Password : ");
		String uPass = sc.nextLine(); 
		try
		{
		boolean login = service.validateUsers(uid,uPass);
		if(login)
		{
			System.out.println("You have logged in succesfully");
			throw new LoginInvalidException();
		}
		else
		{
			System.out.println("Invalid User ");
			
		}
	    }catch(LoginInvalidException e)
		{
			e.getMessage();
		}
	}	
}


