package com.flightmanagement.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.flightmanagement.dto.UserDetails;
public class FlightDaoImpl implements FlightDao
{
	private Connection connection=null;
	private PreparedStatement pst;
	public void openConnection()
	{
		try
		{
			String driverName = "oracle.jdbc.driver.OracleDriver";
			  Class.forName(driverName);
			  connection = DriverManager.getConnection( "jdbc:oracle:thin:@localhost:1521:xe","scott","tiger");
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
	}
	public void close()
	{
		try
		{
			connection.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	 public boolean Signup(UserDetails ud)
	 {
		 openConnection();
		 boolean b=false;
		 try
		 {
			    pst=connection.prepareStatement("insert into users values(?,?,?,?,?,?,?)");
				pst.setInt(1, ud.getUser_id());
				pst.setString(2, ud.getUser_type());
				pst.setString(3, ud.getUser_name());
				pst.setString(4, ud.getUser_password());
				pst.setLong(5, ud.getUser_phoneno());
				pst.setString(6, ud.getUser_email());
				pst.setString(7,ud.getUser_state());
				pst.executeQuery();
				System.out.println("Sign Up Successfull");
				b=true;
		 }
		 catch(SQLException e)
		 {
			 e.printStackTrace();
		 }
		 close();
		 return b;
	     }
	 public boolean validateUsers(String uid, String uPass)
		{
			openConnection();
			try 
			{
				pst = connection.prepareStatement("select * from Users where user_id=? and user_password =? ");
				pst.setString(1, uid);
				pst.setString(2, uPass);
				if(pst.executeQuery().next())
					return true;
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				close();
			}
			return false;
		}
}


