package com.flightmanagement.dao;
import com.flightmanagement.dto.UserDetails;
public interface FlightDao
{
	public void openConnection();
	public void close();
	public boolean Signup(UserDetails ud);
	public boolean validateUsers(String userid, String userpassword);
}
