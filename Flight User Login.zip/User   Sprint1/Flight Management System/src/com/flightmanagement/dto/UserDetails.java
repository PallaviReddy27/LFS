package com.flightmanagement.dto;
public class UserDetails {
    private int user_id;
    private String user_type;
    private String user_name;
    private String user_password;
    private long user_phoneno;
    private String user_email;
    private String user_state;
	
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public long getUser_phoneno() {
		return user_phoneno;
	}
	public void setUser_phoneno(long user_phoneno) {
		this.user_phoneno = user_phoneno;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_state() {
		return user_state;
	}
	public void setUser_state(String user_state) {
		this.user_state = user_state;
	}
	public UserDetails() {}
	public UserDetails(int userid, String usertype, String username, String password,long phoneno, String email, String state)
       {
    	    this.user_id=userid;
    	    this.user_type=usertype;
    	    this.user_name=username;
    	    this.user_password=password;
    		this.user_phoneno=phoneno;
    		this.user_email=email;
    		this.user_state=state;
    		}
	public UserDetails(int userid, String password) {
		return;
	}
	@Override
	public String toString() {
		return "UserDetails [userid=" + user_id + ", usertype=" + user_type + ", username=" + user_name + ", userpassword="
				+ user_password + ", userphoneno=" + user_phoneno + ", useremail=" + user_email + "]";
	}
}