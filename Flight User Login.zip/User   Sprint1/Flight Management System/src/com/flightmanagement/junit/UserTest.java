package com.flightmanagement.junit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.flightmanagement.dao.FlightDao;
import com.flightmanagement.dao.FlightDaoImpl;
import com.flightmanagement.service.FlightService;
import com.flightmanagement.service.FlightServiceImpl;
public class UserTest 
{
	FlightDao fdao=null;
	@Before
	public void setUp()
	{
		fdao=new FlightDaoImpl();
	}
	@After
	public void tearDown()
	{
		fdao=null;
	}
	FlightService fs=new FlightServiceImpl();
    
	@Test
	public void testEquals() {
		Assert.assertEquals(true,fs.validateUsers("123", "anurag"));
	}
	@Test
	public void testNotEquals() {
		Assert.assertNotNull(false);
	}
}
