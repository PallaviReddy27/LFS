package com.flightmanagement.utils;
@SuppressWarnings("serial")
public class LoginInvalidException extends Exception{
   public LoginInvalidException()
   {
	   super("Invalid User");
   }
}
