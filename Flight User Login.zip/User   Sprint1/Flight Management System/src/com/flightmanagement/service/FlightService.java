package com.flightmanagement.service;
import com.flightmanagement.dto.UserDetails;
public interface FlightService 
{
	public void Signup(UserDetails ud);

	public boolean validateUsers(String uid, String uPass);

}
