package com.flightmanagement.service;
import com.flightmanagement.dto.UserDetails;
import com.flightmanagement.dao.FlightDao;
import com.flightmanagement.dao.FlightDaoImpl;
import com.flightmanagement.service.FlightService;
public class FlightServiceImpl implements FlightService{
      FlightDao u=new FlightDaoImpl();
	@Override
	public void Signup(UserDetails ud) {
		u.Signup(ud);
	}
	@Override
	public boolean validateUsers(String uid, String uPass) {
		return u.validateUsers(uid, uPass);
	}
}
